﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace movieee
{
    class Program
    {
        static void Main(string[] args)
        {
            Program.Login();
            Program.Home();
        }
        static void Login()
        {
            Console.WriteLine("\t \t \t ----------------------------------  \n");
            Console.WriteLine("\t \t \t   MOVIE TICKET BOOKING SYSTEM \n ");
            Console.WriteLine("\t \t \t  ----------------------------------");
            Console.WriteLine();

            Console.Write("\n\t\t\tPress 1 for Login by User :");
            int option = Convert.ToInt32(Console.ReadLine());

            switch (option)
            {
                case 1:

                    Console.Write("Enter user name :");
                    string user = (Console.ReadLine());
                    Console.Write("Enter password :");
                    string password = (Console.ReadLine());
                    if (user == "user")
                        Console.WriteLine("Login successful");

                    break;
            }
        }
        static void Home()
        {
            Console.Clear();
            Console.WriteLine("\t \t \t ----------------------------------  \n");
            Console.WriteLine("\t \t \t   MOVIE TICKET BOOKING SYSTEM \n ");
            Console.WriteLine("\t \t \t  ----------------------------------");
            Console.WriteLine();
            Console.WriteLine("\t \t \t         WWELCOME !");
            Console.WriteLine();
            Console.WriteLine("\t \t \t        <1>  Movie Names And Registration");
            Console.WriteLine("\t \t \t        <2>  For Information");
            Console.WriteLine("\t \t \t        <3>  Exit");
            Console.Write("\t \t \t        Enter your Choice :");
            int choice = Convert.ToInt32(Console.ReadLine());

            Console.Clear();
            if (choice == 1)
            {
                Console.WriteLine("\t \t \t        Available Shows are: ");
                Console.WriteLine("\t \t \t        AVENGERS! ");
                Console.WriteLine("\t \t \t        THE NUN! ");
                Console.WriteLine("\t \t \t        HOWL! ");
                Console.WriteLine("\t \t \t        DEADPOL! ");
                Console.WriteLine("\t \t \t        ANTMAN! ");
                Console.WriteLine("");

                Console.Write("\t \t \t        Choose Any Show : ");
                string choose = Console.ReadLine().ToLower();
                Console.WriteLine("");

                if (choose == "avengers" || choose == "the nun" || choose == "howl" || choose == "deadpool" || choose == "antman")
                {
                    Movie();

                }
                else
                {
                    Console.WriteLine("\t \t  We donot have Tickets of this Movie.... SORRY!!....");

                    Console.WriteLine();
                    Console.WriteLine("Do you want to go again to main menu-(yes/no) \b ");
                    string ho = Console.ReadLine();
                    if (ho == "y" || ho == "yes")
                    {
                        Program.Home();
                        Console.ReadLine();
                    }
                    else
                    {
                        Exit();
                        return;
                    }
                    Console.ReadLine();
                }
            }

            else if (choice == 2)
            {
                Console.WriteLine("... For further information Please visit our Site OR Contact us on  123456789......\t THANK YOU!!..");

                Console.WriteLine();
                Console.WriteLine("Do you want to go again to main menu-(yes/no) \b ");
                string ho = Console.ReadLine();
                if (ho == "y" || ho == "yes")
                {
                    Program.Home();
                    Console.ReadLine();
                }
                else
                {
                    Exit();
                    return;
                }

            }
            else if (choice == 3)
            {
                Exit();
            }
        }
        public static void Exit()
        {
            Console.Clear();
            Console.WriteLine("\t \t \t ----------------------------------  \n");
            Console.WriteLine("\t \t \t   MOVIE TICKET BOOKING SYSTEM \n ");
            Console.WriteLine("\t \t \t  ----------------------------------");

            Console.WriteLine();
            Console.WriteLine("\n\t\t Thanks for Choosing our online movie ticket booking systen:\n\t\t\tHope to see you Again");
            Console.ReadLine();
        }
        public static void Movie()
        {

            Console.WriteLine("The Date & TImings Of This Show Are ");
            Console.WriteLine("\t \t \t       (1) MONDAY (11 am TO 04 am)");
            Console.WriteLine("\t \t \t        (2) SATURDAY (01 am TO 06 am)");
            Console.WriteLine("\t \t \t        (3) SUNDAY (04 am TO 04 pm)");
            Console.Write("\t \t \t        Enter your Choice :");
            int select = Convert.ToInt32(Console.ReadLine());
            if (select == 1 || select == 2 || select == 3)
            {
                Console.WriteLine();
                Console.WriteLine("If You want to proceed PLEASE FULLFILL FOLLOWING REQUIREMENTS! ");
                Console.WriteLine();
                Console.Write("\t \t Enter your Name = \b ");
                string name = Console.ReadLine();
                Console.Write("\t \t Enter your Contact Number = \b ");
                double conctnum = Convert.ToDouble(Console.ReadLine());
                Console.Write("\t \t Enter Date for your movie show:");
                string dt = Console.ReadLine();

                Console.WriteLine();

                Console.WriteLine("\t \t Your booking is done");
                Console.WriteLine();

                Console.Write("\t \t Do you have DI card (y/n) :  ");
                string diCard = Console.ReadLine();

                if (diCard == "y")
                {

                    Console.Write("\t  Enter card number: \b ");
                    double cardnum = Convert.ToDouble(Console.ReadLine());

                    Console.Write("\t  \t Paying : \b ");
                    double paying = Convert.ToDouble(Console.ReadLine());

                    Console.Write("\t Enter the Name of card holder :");
                    string cardName = Console.ReadLine();

                    Console.Write("\t Expiry(MM/YYYY)");
                    string Date = Console.ReadLine();
                    Console.Clear();

                    Console.WriteLine("\t \t \t ----------------------------------  \n");
                    Console.WriteLine("\t \t \t   MOVIE TICKET BOOKING SYSTEM \n ");
                    Console.WriteLine("\t \t \t  ----------------------------------");
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("\n\t\t\t Name      :" + name);
                    Console.WriteLine("\t\t\t Contact No  :" + conctnum);
                    Console.WriteLine("\t\t\t Date of your movie show:" + dt);
                    Console.WriteLine("\t\t\t Show No.    :Show" + select);
                    Console.WriteLine("\t\t\t Your Card Number:" + cardnum);
                    Console.WriteLine("\t\t\t Your Paying:" + paying);

                }
                else
                {
                    Console.WriteLine("\t\t\tcash on delivery...");
                    Console.WriteLine("\t\t\tPick your Address:");
                    string add = Console.ReadLine();
                    Console.ReadLine();
                    Console.Clear();

                    Console.WriteLine("\t \t \t ----------------------------------  \n");
                    Console.WriteLine("\t \t \t   MOVIE TICKET BOOKING SYSTEM \n ");
                    Console.WriteLine("\t \t \t  ----------------------------------");
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("\n\t\t\t Name      :" + name);
                    Console.WriteLine("\t\t\t Contact No  :" + conctnum);
                    Console.WriteLine("\t\t\t Date of your movie show:" + dt);
                    Console.WriteLine("\t\t\t Show No.    :Show" + select);
                    Console.WriteLine("\t\t\tPayment Method    :Cash on Delivery");
                    Console.WriteLine("\t\t\tYour Address:" + add);
                    Console.WriteLine("\t\t\tThanks for buying tickets:");
                }
                Console.WriteLine();
                Console.WriteLine("Do you want to go again to main menu-(yes/no) \b ");
                string ho = Console.ReadLine();
                if (ho == "y" || ho == "yes")
                {
                    Program.Home();
                    Console.ReadLine();
                }
                else
                {
                    Exit();
                    return;
                }


            }

            else
            {

                Console.WriteLine("\n\t\t\tThere is no show available for this movie");
                Console.WriteLine();
                Console.WriteLine("\t\t  Do you want to go again to main menu-(yes/no)");
                string ho = Console.ReadLine();
                if (ho == "y" || ho == "yes")
                {
                    Program.Home();
                    Console.ReadLine();
                }
                else
                {
                    Exit();

                }
            }
            Console.ReadLine();
        }
    }
}